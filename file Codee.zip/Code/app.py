import os
from flask import Flask, render_template, request, redirect, url_for, session,flash
from pymongo import MongoClient
import hashlib
import io
import uuid
app = Flask(__name__, static_url_path='/static')
app.secret_key = 'your_secret_key'
client = MongoClient('mongodb://localhost:27017/')
db = client['PAST']
users_collection = db['users']
app.config['UPLOAD_FOLDER'] = r'D:\Projects\fileduplication\uploadedfolders'
user_hashes = {}

def generate_user_id():
    max_user = users_collection.find_one(sort=[("user_id", -1)])
    if max_user and 'user_id' in max_user:
        return max_user['user_id'] + 1
    else:
        return 100000
    
def generate_unique_folder_name():
    return str(uuid.uuid4())

def create_user_folder(user_folder):
    if not os.path.exists(user_folder):
        os.makedirs(user_folder)

def user_folder_exists(user_folder):
    return os.path.exists(user_folder)

def calculate_sha256(file_content):
    sha256_hash = hashlib.sha256()
    chunk_size = 4096  
    if isinstance(file_content, bytes):
        file_content = io.BytesIO(file_content)
    try:
        while chunk := file_content.read(chunk_size):
            sha256_hash.update(chunk)
    finally:
        if hasattr(file_content, 'seek'):
            file_content.seek(0)
    return sha256_hash.hexdigest()

def store_file(file, folder_path, username):
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    file_path = os.path.join(folder_path, 'file.pdf')
    new_file_content = file.read()
    new_hash = calculate_sha256(new_file_content)
    user = users_collection.find_one({'username': username})
    if 'hash_values' in user and new_hash in user['hash_values']:
        return "Duplicate content."
    with open(file_path, 'wb') as new_file:
        new_file.write(new_file_content)
    users_collection.update_one({'username': username}, {'$addToSet': {'hash_values': new_hash}})
    return "File uploaded successfully."

def check_duplicate_content(new_file_content, username):
    new_hash = calculate_sha256(new_file_content)
    user = users_collection.find_one({'username': username})
    if 'hash_values' in user and new_hash in user['hash_values']:
        return "Duplicate content."
    users_collection.update_one({'username': username}, {'$addToSet': {'hash_values': new_hash}})
    return "File uploaded successfully."

def upload_to_database(file,username):
    new_file_content = file.read()
    new_hash = calculate_sha256(new_file_content)
    users_collection.update_one({'username': username}, {'$addToSet': {'hash_values': new_hash}})
    return "File uploaded successfully."

def get_uploaded_files(username):
    userpath = os.path.join(app.config['UPLOAD_FOLDER'], username)
    files = []

    if user_folder_exists(userpath):
        for filename in os.listdir(userpath):
            file_path = os.path.join(userpath, filename)
            if os.path.isfile(file_path):
                files.append({"filename": filename, "message": "Uploaded"})

    return files

@app.route('/password', methods=['GET', 'POST'])
def password():
    if request.method == 'POST':
        email = request.form.get('email')
    return render_template('password.html')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        exist_user = users_collection.find_one({"username": username})
        if exist_user:
            return render_template('register.html', message="Username already exists.")
        else:
            password = hashlib.sha256(password.encode('utf-8')).hexdigest()
            user_id = generate_user_id()
            users_collection.insert_one({
                "user_id": user_id, "username": username, "password": password
            })
            return render_template('login.html', message="Registration successful! Please log in.")
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = users_collection.find_one({'username': username})

        if user and hashlib.sha256(password.encode('utf-8')).hexdigest() == user['password']:
            session['username'] = username
            if 'hash_values' in user:
                user_hashes[username] = set(user['hash_values'])
            else:
                user_hashes[username] = set()
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', message="Invalid credentials")
    return render_template('login.html')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'username' in session:
        username = session['username']
        if request.method == 'POST':
            option = request.form.get('option')  # Assuming 'option' is a select field in your form
            if option in ['INLINE', 'POST-PROCESSING']:
                file = request.files['file']
                folder_name = generate_unique_folder_name()
                userpath = os.path.join(app.config['UPLOAD_FOLDER'], folder_name)
                if not user_folder_exists(userpath):
                    create_user_folder(userpath)
                result_message = store_file(file, userpath, username)
                files = get_uploaded_files(username)
                return render_template('dashboard.html', message=result_message, files=files)
            else:
                return render_template('dashboard.html', message="Invalid Option Selected", files=get_uploaded_files(username))
        else:
            files = get_uploaded_files(username)
            return render_template('dashboard.html', files=files)
    else:
        return redirect(url_for('login'))

@app.route('/uploaded', methods=['POST'])
def uploaded():
    if 'username' in session:
        username = session['username']
        file = request.files['file']
        folder_name = generate_unique_folder_name()
        userpath = os.path.join(app.config['UPLOAD_FOLDER'], folder_name)
        if not user_folder_exists(userpath):
            create_user_folder(userpath)
        if file:
            option = request.form.get('option')
            if option == 'INLINE':
                result_message = check_duplicate_content(file.read(), username)
                if "Duplicate content" not in result_message:
                    return render_template('uploaded.html', message="File uploaded successfully")
                else:
                    return render_template('uploaded.html', message="Duplicate content")

            elif option == 'POST-PROCESSING':
                upload_to_database(file,username)
                return render_template('uploaded.html', message="File uploaded successfully to database")
            else:
                return render_template('uploaded.html', message="Invalid Option Selected")
        else:
            return render_template('uploaded.html', message="No File Uploaded")
    else:
        return redirect(url_for('login'))
if __name__ == '__main__':
    app.run(debug=True, port=5001)
